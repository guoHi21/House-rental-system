package com.gkj.houserent;

import com.gkj.houserent.view.HouseView;

public class HouseRentApp {
    public static void main(String[] args) {
        //创建 HouseView对象,并且显示我们的主菜单,是整个程序的入口
        new HouseView().mianMenu();
        System.out.println("==你退出了房屋出租系统==");
    }
}
