package com.gkj.houserent.view;

import com.gkj.houserent.domain.House;
import com.gkj.houserent.service.HouseService;
import com.gkj.houserent.utils.Utility;

/**
 * 1.显示界面(界面层)
 * 2.接收用户的输入,调用HouseService中的方法完成对房屋信息的操作
 * 3.调用 HouseService 完成对房屋信息的操作
 */
public class HouseView {
    private boolean loop = true;  //用于控制显示菜单
    private char key = ' ';   //接收用户选择的是哪一个菜单
    private HouseService houseService = new HouseService(2);  //创建HouseService对象，设置数组的大小为10
    private int houseNums = 0;

    //完成退出确认
    public void exit(){
        //使用由Utility类中定义的方法
        char c = Utility.readConfirmSelection();
        if(c=='Y') {
            loop = false;
        }
    }
    //编写 updateHouse()方法，修改房屋信息
    public void updateHouse() {
        System.out.println("=========修改房屋信息============");
        System.out.println("请选择待修改房屋编号(-1)表示退出");
        int updateId = Utility.readInt();
        if(updateId == -1){
            System.out.println("===========已放弃修改房屋信息============");
            return;
        }

        //根据输入得到的updateId,查找对象
        House house = houseService.findById(updateId);  //返回的是引用类型[就是数组里的那个元素]
        //在后面 house.setXxx()会修改 HouseService中的数组的元素
        if(house == null){
            System.out.println("===========编号不存在,无法修改==============");
            return;
        }
        System.out.println("姓名("+house.getName()+"):");
        String name = Utility.readString(8,"");  //这里用户直接回车表示不修改,默认空串
        if(!"".equals(name)){
            house.setName(name);
        }

        System.out.println("电话("+house.getPhone()+"):");
        String phone = Utility.readString(12,"");
        if(!"".equals(phone)){
            house.setPhone(phone);
        }

        System.out.println("地址"+house.getAddress()+"):");
        String address = Utility.readString(18,"");
        if(!"".equals(address)){
            house.setAddress(address);
        }

        System.out.println("月租("+house.getRent()+"):");
        int rent = Utility.readInt(-1);
        if(rent != -1){
            house.setRent(rent);
        }

        System.out.println("状态("+house.getState()+"):");
        String state = Utility.readString(3,"");
        if(!"".equals(state)){
            house.setState(state);
        }
        System.out.println("修改房屋信息成功");
    }

    //编写 delHouse()方法，删除房屋信息 接收输入的id，调用 Service中的del方法
    public void delHouse() {
        System.out.println("\n==============删除房屋===============");
        System.out.println("\n=====请输入待删除房屋的编号(-1退出)=====");
        int delId = Utility.readInt();
        if (delId == -1) {
            System.out.println("===========放弃删除房屋信息============");
            return;   //表示结束一个方法
        }
        //System.out.println("请确认是否确定删除(Y/N),请小心选择: ");  //下面调用的方法包含了这个提示
        char choice = Utility.readConfirmSelection();  //该方法本身就有循环判断的逻辑  command+B
        if (choice == 'Y') { //真的要删除
            if (houseService.del(delId)) {   //调用del()方法,返回 true代表删除成功,否则失败
                System.out.println("===========删除房屋信息成功============");
            } else {
                System.out.println("==========编号不存在删除失败===========");
            }
        } else {
            System.out.println("===========放弃删除房屋信息============");
        }
    }

    //查找房屋信息
    public void findHouse(){
        System.out.println("============查找房屋信息=============");
        System.out.println("请输入要查找的 id");
        int findId = Utility.readInt();
        //调用方法(业务在 Service中)
        House house = houseService.findById(findId);
        if(house!=null){
            System.out.println(house);
        }else{
            System.out.println("===========查找的 id 信息不存在==============");
        }
    }





    //编写 addHouse()方法，接收输入，添加房屋信息 创建 House对象,接收输入
    public void addHouse(){
        System.out.println("\n==============添加房屋================");
        System.out.print("姓名：");
        String name = Utility.readString(8);  //名字最长有8个字符
        System.out.print("电话：");
        String phone = Utility.readString(12);
        System.out.print("地址：");
        String address = Utility.readString(16);
        System.out.print("月租：");
        int rent = Utility.readInt();
        System.out.print("状态：");
        String state = Utility.readString(3);
        //创建一个House对象，将用户输入的信息封装到House对象中
        //id应该是系统分配的，不能自己设置(规定按自增长的方式)
        House newhouse = new House(0,name,phone,address,rent,state);
        if(houseService.add(newhouse)){
            System.out.println("========添加房屋成功=========");
        }else{
            System.out.println("========添加房屋失败=========");
        }
    }


    //编写listHouse()显示房屋列表
    public void ListHouse(){
        System.out.println("\n==============房屋列表==================");
        System.out.println("编号\t\t房主\t\t电话\t\t地址\t\t月租\t\t状态(未出租/已出租)");
        House[] houses = houseService.list(); //得到所有的房屋信息

        for(int i=0;i<houses.length;i++){
            if(houses[i]==null){
                break;
            }
            System.out.println(houses[i]);
        }
        System.out.println("房屋列表展示完毕");
    }


    //显示主菜单
    public void mianMenu(){
        do{
            System.out.println("===========房屋出租系统菜单============");
            System.out.println("\t\t\t1.新 增 房 源");
            System.out.println("\t\t\t2.查 找 房 屋");
            System.out.println("\t\t\t3.删 除 房 屋 信 息");
            System.out.println("\t\t\t4.修 改 房 屋 信 息");
            System.out.println("\t\t\t5.房 屋 列 表");
            System.out.println("\t\t\t6.退      出");
            System.out.print("请输入你的选择(1～6):");
            key = Utility.readChar();
            switch(key){
                case '1':
                   // System.out.println("新 增");
                    addHouse();
                    break;
                case '2':
                   // System.out.println("查 找");
                    findHouse();
                    break;
                case '3':
                    delHouse();
                    //  System.out.println("删 除");
                    break;
                case '4':
                   // System.out.println("修 改");
                    updateHouse();
                    break;
                case '5':
                   // System.out.println("房 屋 列 表");
                    ListHouse();
                    break;
                case '6':
                  //  System.out.println("退 出");
                    //把下面的功能封装一下
//                    //使用由Utility类中定义的方法
//                    char c = Utility.readConfirmSelection();
//                    if(c=='Y') {
//                        loop = false;
//                    }
                    exit();
                    break;
                default:
                    System.out.println("选择有误，请重新选择");
                    break;
            }
        }while(loop);

    }
}
