package com.gkj.houserent.service;


import com.gkj.houserent.domain.House;

/**
 * HouseService <==> 类,业务层 ,用于存放实现功能的具体代码
 * 定义 House[]数组,保存 House对象
 * 1.响应 HouseView的调用
 * 2.完成对房屋信息的添加,删除,修改,查询等操作 crud(create,read,update,delete)
 */
public class HouseService {
    private House[] houses;   //保存 House对象
    private int houseNums = 1 ;    //记录当前有多少个房屋信息
    private int idCounter = 1;    //id自增长的机制 记录当前的 id 增长到哪一个值了
    //构造器
    public HouseService(int size) {
        houses = new House[size];
        //为了配合 测试列表信息,先初始化一些数据
        houses[0] = new House(1,"jack","112","海淀区",2000,"未出租");
    }

    //find()方法,返回 House 对象
    public House findById(int findId){
        for(int i=0;i<houseNums;i++){
            if(findId == houses[i].getId()){
                return houses[i];   //找到返回对象
            }
        }
        return null;  //否则返回空
    }


    //del()方法
    public boolean del(int delId){
        //先找到删除的房屋信息对应的下标(搞清楚id和下标的关系)
        int index = -1;
        for(int i=0;i<houseNums;i++){
            if(delId==houses[i].getId()){    //要删除的房屋 (id)，是数组中的下标为i的元素
                index = i;
            }
        }
        if(index == -1){    //说明 delId在数组中不存在
            return false;
        }
        //如果找到,就把后面的元素都向前移动一位，覆盖这里要删除的数组元素
        for(int i=index;i<houseNums-1;i++){      //
            houses[i] = houses[i+1];
        }
//        houses[houseNums-1] = null;   //把当前存在的房屋信息的最后一个设置为 null
//        houseNums--;  //数组长度减1
        houses[--houseNums] = null;  //等价于上面两行
        return true;
    }



    //add()方法，添加新对象，返回boolean
    public boolean add(House newHouse) {
        //判断是否还可以继续添加(是否数组已经满)(暂时不考虑扩容) 如何加入数组扩容机制
        if(houseNums == houses.length){//满了
            System.out.println("数组已经满了，不能再添加");
            return false;
        }
        //把 newHouse这个新对象，放入到数组的最后
//        houses[houseNums] = newHouse;
//        houseNums++;  //记录当前有多少个房屋信息
        houses[houseNums++] = newHouse;   //等价于以上两句
        //需要设计一个 id 自增长的机制
//        idCounter++;
//        newHouse.setId(idCounter);  //更新了新添加的house 的 id
        newHouse.setId(++idCounter);   //等价于以上两句
        return true;
    }
    //list()方法，返回 houses
    public House[] list() {
        return houses;
    }
}
