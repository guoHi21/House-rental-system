package com.gkj.houserent.utils;

public class TestUtility {
    public static void main(String[] args) {

        //这是一个测试类，用完就可以删除
//        String s = Utility.readString(3);  //要求输入一个字符串，长度最大为3
//        System.out.println("s="+s);

        String s2 =  Utility.readString(10,"gkj");  //若用户没有输入直接回车就赋给一个默认值为gkj
        System.out.println("s2="+s2);

        //此处直接使用类的方法，不用创建对象
        //如果当前的方法是 static 时，就是一个静态方法,静态方法可以直接通过类名调用=》细节后面再讲
    }
}
